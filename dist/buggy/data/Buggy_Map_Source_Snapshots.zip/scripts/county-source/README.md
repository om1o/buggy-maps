# City of Miami property snapshot

The November 22, 2026 Miami-time snapshot retains all 33,588 disclosed single-family records from the City of Miami query. The source returned 33,590 records; two with undisclosed addresses are excluded. This is not a census of all Miami-Dade homes or current portal listings. The query, selected fields, source hashes, exclusions and field coverage are in `manifest.json`.

Only property facts were requested. Owner names, mailing addresses and personal contact fields were not acquired. Source assessment years are preserved exactly and are not asking prices.

The archive merge contains 34,729 unique property records, with county facts linked into 561 existing records and 33,027 new county-only records. Exact shared folios are deduplicated; distinct folios sharing a street address are retained. Search aliases preserve earlier links.

## Rebuild and verify

Run from the repository root using Node, Python, Pillow and NumPy:

```sh
node scripts/build-city-expansion.mjs
python scripts/compress-property-records.py
python scripts/package-property-data.py
node scripts/verify-city-expansion.mjs
node scripts/verify-property-search.mjs
python scripts/county-source/verify_tiles.py
```

`fetch-city-homes.py` documents snapshot acquisition. Running `python scripts/county-source/fetch_tiles.py` reuses verified existing tiles and fetches any missing ones from the public county imagery service. Both tile scripts accept explicit snapshot and tile-directory arguments. A rerun writes its own manifest and verification result into the chosen tile directory.

## Images

All 125 county aerial tiles are stored in `dist/buggy/media/county-tiles/`. Each 2560×2560 WebP covers a 1280-meter square in EPSG:3857, including 128 meters of padding around a 1024-meter grid cell. The app centers a 216×144 projected-meter view on each county property point. The complete audit found no missing, out-of-bounds or blank property crops. These are aerial map photographs, not front exterior or drone photographs.

The source service metadata conflicts about the capture year, so no precise date is asserted. `aerial-tiles-manifest.json` records source, bounds and hashes; `aerial-verification.json` records the complete geometric and pixel audit. Address-to-image assignment uses official property coordinates; the audit is not individual visual confirmation of every building. Existing exterior photographs, tours and photographer drone galleries remain attached only to previously verified matching properties.

The public CSV and ZIP contain property data and image/source links. The ZIP does not embed the image cache. The running site serves the cache directly without requiring a county image request for each new property.

Deployed county detail shards and the original archive's record blocks use lossless gzip compression; the downloadable ZIP retains plain JSON for portability. The site uses browser-native decompression. Index and place data also have compressed copies with plain-file fallbacks.
