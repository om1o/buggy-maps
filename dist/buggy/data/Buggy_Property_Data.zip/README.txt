Buggy Miami property and school atlas

The home catalog has 35,041 searchable records.
Its base archive has 34,729 records, including 33,588
matched to the City of Miami single-family roll. The gallery supplement adds
312 homes elsewhere in Miami-Dade County, verified against county
single-family records and an address-matched publisher photo tour. The base and
supplement contain distinct home IDs.

Buggy_Miami_Properties.csv contains every home, its property link and its
parcel-centered aerial source when available. The machine-readable home
catalog combines index.json and gallery-homes.json. Match records using id.
county/ contains parcel-keyed detail files (gh prefixes identify the supplement).
properties/ contains dated listing facts and any matching county details.

listing-tours.csv inventories 995 in-app publisher
tours with a matched street address, ZIP, source URL and review date. The
publisher operates the original photo viewer. The atlas has 1,000
unique gallery homes including its address-matched local galleries. Photos, angles, availability
and listing status may change. media.json and image-sources.csv credit the
address-matched licensed and public-domain images. Some image URLs begin
with /buggy/ and resolve against https://miami-homes-march-2026.aoraboracora.chatgpt.site.
County aerial photography shows the parcel from above. The CSV and source
files reference aerial imagery and publisher-hosted gallery assets by URL.

Miami-Dade-Schools.csv is the school directory in spreadsheet format.
schools.json contains 1,190 school records and their documented
sources, coverage and observation dates. school-image-credits.csv describes
the school photography and its reuse terms. School fields vary by directory.
search-places.json separately preserves nearby school and neighborhood labels
from the property archive. A nearby school or a driving route does not establish
school assignment, a pickup time, or availability of Buggy transportation.

The initial City of Miami roll was retrieved 2026-11-23T03:54:56.326980+00:00 (UTC).
Shared folios were merged and original links resolve through property-aliases.json.
The county-source folder preserves the public property fields and acquisition
manifest behind that initial roll. gallery-homes.json documents the countywide
gallery supplement. Recorded transfers and assessments retain their source dates.

Public county property records
https://gisweb.miamidade.gov/arcgis/rest/services/MD_SQLPictometry_Connect/MapServer/0
County aerial imagery
https://gisweb.miamidade.gov/arcgis/rest/services/MapCache/MDCImagery_WebMercator/MapServer
City neighborhood boundaries
https://gis.miami.gov/gis/rest/services/Maps/Neighborhoods/MapServer/0
Publisher photo viewer and reuse terms
https://www.propertypanorama.com/terms
