# Miami single-family property research

Reviewed November 15, 2026. Start with `property_index.csv` for a joined list of 1,703 property records. Use the source-specific files for every observation, original source link, price type and date. The data uses Miami mailing or source city labels. Some properties fall outside the incorporated City of Miami.

| Research set | Properties or checks | What the date means |
| --- | ---: | --- |
| Zillow archive, March 6 | 1,696 | Each property was classified as single-family and for sale at capture. The median of 1,688 positive asking prices was $867,000. Eight reported zero. |
| Zillow archive, March 10 and 12 | 4 | Four additional properties had a recently sold status at capture. These are distinct from the March 6 houses. |
| Homes.com property histories | 8 | Each row records a dated listing or sale event. Seven addresses match the March 6 archive, including four with later sales. |
| Paired Zillow and Homes.com pages, reviewed November 15 | 3 | Each pair displayed the same asking price and MLS ID. The indexed pages varied in freshness. One address also appears in the eight histories. |

## Joining and field coverage

The index uses the 1,700 March Zillow property IDs as its starting set. Two November comparisons introduce additional Zillow IDs. One Homes.com history has a Miami mailing address, an unmatched street/ZIP and a West Miami location in the listing details. That record uses the Homes.com property identifier. Across the two sets of page checks there are ten distinct Homes.com URLs. Review counts across sources overlap.

The index includes the latest price observation available in these files, labeled by type and date. A March asking price, a recorded sale and an asking price displayed on a page reviewed in November describe different events. The source files retain each observation, including older price points. A zero is a source value and is excluded from asking-price statistics. Unreported fields are blank.

The March 6 field dictionary accounts for 136 source field names. The detailed export retains 131 at least once, including fields that may be blank for individual properties. The files preserve supplied factual details about rooms, construction, lots, assessed values, price and tax histories, schools and other features. They omit photos, tours, personal contact details and seller-written marketing copy. Factual profiles summarize the available attributes. No property media is included.

## Files and verification

- `property_index.csv` provides a sortable inventory with source groups, links, the documented price and the date it refers to.
- `zillow/homes.csv` and `zillow/later/observations.csv` provide the individual property observations with source IDs and capture dates.
- `zillow/miami_homes.jsonl.gz` and `zillow/later/observations.jsonl.gz` preserve the detailed nested source fields. Decompress these gzip files and read one JSON object per line.
- `zillow/README.md` explains source hashes, selection, archive screening, record-level checks, disclosed and withheld addresses, builder listings, units and missing values. `zillow/source_fields.csv` and `zillow/field_paths.csv` document availability.
- `homescom/homescom_examples.csv` and `homescom/november_pairs.csv` document eight historical cases and three paired price checks. Each has linked source pages. The adjoining notes explain how the examples were selected and dated.
- `checksums.sha256` records each packaged file's SHA-256.

No same-date citywide export from both portals was available. These sources cannot measure the share of all current listings. The portal search areas also differ. A full inventory would require authorized exports for both sources, a shared boundary and a common observation date.

[Pinned archive](https://huggingface.co/datasets/dev0524/resi-dataset/tree/05c08ac6a6afabaf074cd0061164600caa85e969) · [Zillow Miami houses](https://www.zillow.com/miami-fl/houses/) · [Homes.com Miami houses](https://www.homes.com/miami-fl/houses-for-sale/)
