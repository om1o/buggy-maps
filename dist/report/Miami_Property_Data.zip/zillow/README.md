# Miami properties on Zillow

This directory contains 1,700 distinct Zillow property IDs from the third-party `dev0524/resi-dataset` archive. All have the source city Miami, state FL and property type `SINGLE_FAMILY`. The base file holds 1,696 properties marked for sale on March 6, 2026 UTC. Two later files supply four other properties marked recently sold on March 10 and 12. All 1,000 IDs in the earlier sample appear in the base, with their original archive positions. A Miami mailing address can fall outside municipal boundaries.

## Reading the files

| File | What it contains |
| --- | --- |
| `homes.csv` | One row per March 6 property, including price, address where disclosed, listing link, property facts, factual description and previous-sample flag |
| `miami_homes.jsonl.gz` | One detailed record per CSV row, in the same order. Nested arrays include historical prices, tax assessments, nearby schools, construction, interior and community details where supplied |
| `later/observations.csv` | Four subsequent records marked recently sold. Their asking-price column is blank. Reported price, currency and last sale price have separate columns |
| `later/observations.jsonl.gz` | Four detailed records, each wrapped in `home` and `provenance` |
| `source_rows.csv` | One decision for each of the 6,575 March 6 source records. Included rows carry their Zillow ID and the 1-based source position |
| `source_fields.csv` | Coverage of all 136 original March 6 top-level keys and treatment of their values during export |
| `field_paths.csv` | Structure, types and number of homes exposing each field path in the detailed base file. A present path can hold an explicit null |
| `summary.json` | Counts, prices, timestamp bounds, ZIP distribution and the base source version |
| `prior_1000_index.csv` | Original 1,000 Zillow IDs and archive positions for joining older files |
| `later/verified.json` | Source URL, hash, original row, time, status and most recent sale for every additional observation |
| `later/source_coverage.json` | Screening method and complete-scan file counts and hashes for the search for additional observations |

Join records using `zpid`. Keep parcel IDs, ZIPs, county FIPS and MLS IDs as text. CSV blanks denote a missing or withheld value. The raw-style JSON distinguishes absent fields, explicit nulls, empty collections, source zero and false values. Source field names and identifiers appear as provided.

## Selection and interpretation

- The pinned Miami file contains 6,575 records across all property types. Its 1,742 single-family records include 46 with another city/state label. The other 4,833 records have a different property type. No duplicate ZPIDs or duplicate disclosed street/ZIP pairs required removal among the 1,696 qualifying records. Rows with missing price, rooms, size or complete address were eligible. The only pre-foreclosure record in the full file falls outside the selected group.
- Seven matching records have a unit marker in their street address. Five withhold their street address, so these retain basic prices, sizes, dates and a city/ZIP-only original Zillow link. They omit precise coordinates, parcels, comparables, geographic hints, descriptions and nested location details. The `address_review` column identifies both exceptions. Twenty records use Zillow community URLs and can describe builder plans; the source classifications do not establish that all homes are completed structures.
- The 1,696 for-sale records span 41 ZIPs. Eight have a source asking price of zero. The median of the 1,688 positive USD asks is $867,000. Its 25th and 75th percentiles are $675,000 and $1,541,175. Those statistics cover the March 6 file only. The four sale amounts belong to different homes observed later; combining them with the asks would mix different measures.
- For 1,641 homes in the base, `confirmed_living_area_sqft` has an explicit matching square-foot unit, either in the dedicated area field or in the structured interior details. Retain each lot measurement's own unit. Source percentages and historical Zestimate amounts keep their recorded scales.
- The delivered March 6 JSON includes 131 original top-level fields across the selected homes. It contains 19,069 price-history events, 34,376 annual tax entries and 148,593 historical estimate entries. Recent sales, delistings, rental listings and asking-price changes may all appear in the price history; read the event type and rental indicator. Nearby and comparable homes do not increment the headline property count.
- No listing images are included. Photo counts and tour availability can remain as ordinary numeric or boolean facts. The export removes media and tour URLs, original listing-advertising prose, personal contact details and credential-like URL parameters. Only verified-format Zillow or school links in designated fields remain. The short descriptions in the CSVs are generated from recorded property features. Embedded JSON strings for nearby homes and comparables are decoded into structured objects.

## Source version and reproduction

The pinned public source revision is `05c08ac6a6afabaf074cd0061164600caa85e969`. The publisher's `miami-fl.json` file has SHA-256 `458364a7d56c3c49a4e2ce6d1518a0028383b49c393aa98a3c7cf39e92d000a7`. The two additional original filenames, URLs and file hashes appear in `later/verified.json`. This dataset describes observed dates and the examined archive scope. The publisher does not identify a data reuse license in its dataset card.

[Versioned source directory](https://huggingface.co/datasets/dev0524/resi-dataset/tree/05c08ac6a6afabaf074cd0061164600caa85e969)

Run with Python 3.11 or later, from this directory. Store the original downloaded source files outside the delivery folder. The package includes the earlier sample index and expansion coverage file used by these commands.

```sh
python scripts/build.py /path/to/originals/miami-fl.json .
python scripts/verify.py /path/to/originals/miami-fl.json .
python scripts/later.py /path/to/originals .
```

The base verifier checks every source selection against the delivered row and totals, compares the original data after the documented removals, checks identifier uniqueness, and confirms that all earlier IDs remain. The later-file builder checks each original file hash and row count, then reads back both exports to confirm their provenance, prices, and distinct IDs.
