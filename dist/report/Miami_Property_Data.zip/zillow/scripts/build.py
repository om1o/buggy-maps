"""Rebuild the complete Miami single-family slice of the pinned Miami property archive."""
import argparse
import csv
import gzip
import hashlib
import io
import json
import re
from collections import Counter, defaultdict
from contextlib import ExitStack
from pathlib import Path
from statistics import median, quantiles
from urllib.parse import urlsplit

from source_records import iter_records, UNIT_STREET
from source_facts import CORE, SOURCE, SOURCE_REV, SOURCE_SHA256, confirmed_sqft, paths, present


OMIT = object()
DROP_KEYS = {
    "photos", "photo", "miniCardPhotos", "compsCarouselPropertyPhotos", "providerLogo",
    "streetViewTileImageUrlMediumLatLong", "streetViewServiceUrl", "streetViewMetadataUrlMediaWallAddress",
    "streetViewMetadataUrlMediaWallLatLong", "virtualTourUrl", "jpeg", "agentName", "agentPhoneNumber",
    "brokerPhoneNumber", "postingContact", "email", "phone_number", "management_company_phone_number",
    "brokerName",
}
HIDDEN_KEYS = set("""
    zpid city state zipcode country homeStatus homeType bedrooms bathrooms price currency yearBuilt livingArea
    livingAreaUnits livingAreaValue livingAreaUnitsShort lotAreaValue lotAreaUnits lastSoldPrice dateSoldString
    zestimate rentZestimate taxAssessedValue taxAssessedYear propertyTaxRate daysOnZillow timestamp isUndisclosedAddress
""".split())
REDACTION = {
    "description": "Listing marketing copy omitted. See the factual property_profile in homes.csv.",
    "photos": "Listing media omitted.",
    "streetViewTileImageUrlMediumLatLong": "Image URL omitted.",
    "postingContact": "Personal and contact data omitted.",
    "virtualTourUrl": "Tour URL omitted.",
}
URL_OR_SECRET = re.compile(r"(?:https?://|www\.|[?&](?:api_?key|key|signature|token|sig)=|\bdata:image/|\bmailto:|\btel:|\.(?:jpe?g|png|gif|webp|mp4|mov)(?:\s|$|[?#])|propertypanorama\.com|youtu\.be|vimeo\.com)", re.I)
CONTACT = re.compile(r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b|(?<!\d)(?:\(\d{3}\)[ .-]?\d{3}[ .-]?\d{4}|\d{3}[-. ]\d{3}[-. ]\d{4})(?!\d)", re.I)
TOUR = re.compile(r"\bvirtual tour\b|\bvideo tour\b",re.I)


def normalized(value):
    return " ".join(str(value or "").casefold().split())


def undisclosed(record):
    return str(record.get("isUndisclosedAddress")).lower() == "true" or "undisclosed" in normalized(record.get("streetAddress"))


def unit_marker(record):
    return bool(record.get("unit_number") or UNIT_STREET.search(record.get("streetAddress") or ""))


def in_scope(record):
    return (record.get("city"), record.get("state"), record.get("homeType")) == ("Miami", "FL", "SINGLE_FAMILY")


def safe_link(value, path):
    parts = urlsplit(value)
    if parts.scheme not in {"http", "https"} or parts.query or parts.fragment or parts.netloc != parts.hostname:
        return False
    if parts.hostname in {"www.zillow.com", "zillow.com"}:
        return (path[-1:] in {("url",), ("hdpUrl",)} and
                (bool(re.fullmatch(r"/(?:homedetails|community)/(?:[^/?#]+/)?\d+_zpid/?", parts.path))
                 or (path == ("discovery_input", "url") and bool(re.fullmatch(r"/miami-fl/?", parts.path)))))
    return parts.hostname == "www.greatschools.org" and path == ("schools", "link")


def sanitize(value, hidden_ids, changes, path=()):
    def changed(reason):
        changes[(path[0] if path else "", reason)] += 1
        return OMIT
    if isinstance(value, str):
        if value.lstrip().startswith(("{", "[")):
            try:
                decoded = json.loads(value)
            except ValueError:
                pass
            else:
                return sanitize(decoded, hidden_ids, changes, path)
        if CONTACT.search(value): return changed("contact text")
        if URL_OR_SECRET.search(value):
            if value.startswith(("https://","http://")) and safe_link(value,path): return value
            return changed("media, other URL, or credential-like text")
        if TOUR.search(value) and path[:1] == ("interior_full",):
            return changed("media caption")
        return value
    if isinstance(value, list):
        result=[]
        for elem in value:
            item=sanitize(elem,hidden_ids,changes,path)
            if item is not OMIT:
                result.append(item)
        return result
    if isinstance(value, dict):
        if path and ("zpid" in value) and (str(value.get("zpid") or "") in hidden_ids or undisclosed(value)):
            return changed("nested reference to an undisclosed home")
        if path == ("interior_full",) and TOUR.search(str(value.get("title",""))):
            return changed("media group")
        result = {}
        for k,item in value.items():
            if (k in DROP_KEYS or (not path and k=="description")
                    or (path == ("listing_provided_by",) and k == "name")):
                changes[((path or (k,))[0],"media, marketing, or contact field")]+=1
                continue
            clean = sanitize(item, hidden_ids, changes, path+(k,))
            if clean is not OMIT: result[k]=clean
        return result
    return value


def clean_home(record, hidden_ids, changes):
    if not undisclosed(record):
        return sanitize(record,hidden_ids,changes)
    result = {k:v for k,v in record.items() if k in HIDDEN_KEYS}
    # Only the publisher's city/state/ZIP-only address slug is safe to return on these rows.
    allowed = f"https://www.zillow.com/homedetails/Miami-FL-{record.get('zipcode')}/{record.get('zpid')}_zpid/"
    if record.get("url")==allowed:
        result["url"]=allowed
    for k in record.keys()-result.keys():
        changes[(k,"undisclosed-address scope")]+=1
    return result


def profile(h,sqft,flag):
    subject = "Source-classified single-family property" if flag=="Unit marker in source" else "Single-family house"
    loc = f" in Miami, FL {h.get('zipcode') or ''}".rstrip()
    out = [subject+loc]
    rooms = [f"{v:g} {label if v!=1 else label[:-1]}" for label,v in (("bedrooms",h.get("bedrooms")),("bathrooms",h.get("bathrooms"))) if isinstance(v,(int,float))]
    if rooms: out.append(" and ".join(rooms))
    if sqft is not None: out.append(f"{sqft:,g} sq ft of living area")
    if isinstance(h.get("yearBuilt"),int):out.append(f"Built in {h['yearBuilt']}")
    if isinstance(h.get("lotAreaValue"),(int,float)) and h.get('lotAreaUnits'):
        unit=str(h["lotAreaUnits"]).lower().replace("sqft","square feet")
        out.append(f"Lot of {h['lotAreaValue']:,.3f}".rstrip("0").rstrip(".")+f" {unit}")
    if flag=="Undisclosed address":out.append("The source withholds the address")
    if flag=="Unit marker in source":out.append("The address includes a unit designation")
    return ". ".join(v[0].upper()+v[1:] for v in out)+"."


def csv_writer(stack, dest, filename, headers):
    fp=stack.enter_context((dest/filename).open("w",newline="",encoding="utf-8"))
    writer=csv.writer(fp);writer.writerow(headers)
    return writer


def build(source,dest,prior):
    with source.open("rb") as fp:
        if hashlib.file_digest(fp,"sha256").hexdigest()!=SOURCE_SHA256: raise ValueError("Source SHA-256 mismatch.")
    with prior.open(newline="",encoding="utf-8") as fp:
        baseline={r["zpid"]:int(r["source_array_position_1_based"]) for r in csv.DictReader(fp)}
    if len(baseline)!=1000: raise ValueError("Expected the original 1,000-row index.")
    hidden_ids={str(h.get("zpid")) for h in iter_records(source) if in_scope(h) and undisclosed(h)}
    dest.mkdir(parents=True,exist_ok=True)
    raw_counts,raw_types,raw_status,raw_dates=Counter(),Counter(),Counter(),Counter()
    input_fields,source_nonempty,delivered_nonempty,delivered_fields=Counter(),Counter(),Counter(),set()
    path_counts,path_types,change=Counter(),defaultdict(set),Counter()
    flags,zips,status,dates,hist,edits=Counter(),Counter(),Counter(),Counter(),Counter(),Counter()
    seen_ids,seen_addresses=set(),set()
    facts=[]
    rows_first,rows_last=None,None
    time_min,time_max=None,None
    with ExitStack() as stack:
        rows=csv_writer(stack,dest,"homes.csv",
            [col for col,_ in CORE]+["confirmed_living_area_sqft","property_profile","address_review","previous_1000","source_array_position_1_based"])
        audit=csv_writer(stack,dest,"source_rows.csv",["source_array_position_1_based","source_home_type","source_status","source_city","source_state","source_capture_date","disposition","included_zpid","previous_1000"])
        fields=csv_writer(stack,dest,"source_fields.csv",["source_field","source_present","source_nonempty","delivered_present","delivered_nonempty","handling"])
        nested=csv_writer(stack,dest,"field_paths.csv",["delivered_field_path","observed_types","homes_with_path_including_null"])
        # Fix gzip metadata for byte-identical rebuilds.
        gzbytes=stack.enter_context((dest/"miami_homes.jsonl.gz").open("wb"))
        binary=stack.enter_context(gzip.GzipFile(filename="",mode="wb",fileobj=gzbytes,mtime=0,compresslevel=6))
        document=stack.enter_context(io.TextIOWrapper(binary,encoding="utf-8",newline="\n"))
        delivered_present=Counter()
        for index,raw in enumerate(iter_records(source),1):
            typ=raw.get("homeType") or "Missing"; sts=raw.get("homeStatus") or "Missing"
            t=str(raw.get("timestamp") or "");day=t[:10] or "Missing"
            city,state=raw.get("city"),raw.get("state"); zid=str(raw.get("zpid") or "")
            addr=(normalized(raw.get("streetAddress")),str(raw.get("zipcode") or ""))
            raw_types[typ]+=1; raw_status[sts]+=1; raw_dates[day]+=1
            if typ!="SINGLE_FAMILY": outcome="Excluded: other source home type"
            elif (city,state)!=("Miami","FL"):outcome="Excluded: other source city/state"
            elif not zid: outcome="Excluded: missing Zillow ID"
            elif zid in seen_ids: outcome="Excluded: duplicate Zillow ID"
            elif all(addr) and not undisclosed(raw) and addr in seen_addresses:outcome="Excluded: duplicate disclosed address and ZIP"
            else: outcome="Included"
            raw_counts[outcome]+=1
            previous=zid in baseline and outcome=="Included"
            audit.writerow([index,typ,sts,city,state,day,outcome,zid if outcome=="Included" else None,int(previous)])
            if outcome!="Included":continue
            if previous and baseline[zid]!=index:raise ValueError("Previous source position changed.")
            seen_ids.add(zid)
            if all(addr) and not undisclosed(raw):seen_addresses.add(addr)
            issue=("Undisclosed address" if undisclosed(raw) else "Unit marker in source" if unit_marker(raw) else "No address exception")
            flags[issue]+=1
            home=clean_home(raw,hidden_ids,change);sqft=confirmed_sqft(home)
            text=profile(home,sqft,issue)
            rows.writerow([home.get(k) for _,k in CORE]+[sqft,text,issue,int(previous),index])
            document.write(json.dumps(home,ensure_ascii=False,allow_nan=False,separators=(",",":"))+"\n")
            input_fields.update(raw.keys());source_nonempty.update(k for k,v in raw.items() if present(v))
            delivered_fields.update(home.keys());delivered_present.update(home.keys())
            delivered_nonempty.update(k for k,v in home.items() if present(v))
            obs=defaultdict(set);paths(home,"",obs)
            for key,types in obs.items():path_counts[key]+=1;path_types[key].update(types)
            for k in ("priceHistory","taxHistory","zestimate_history","schools"):hist[k]+=len(home.get(k) or [])
            if sqft is not None:edits["confirmed_living_area_sqft"]+=1
            if previous:edits["previous_1000"]+=1
            if sts=="FOR_SALE" and home.get("currency")=="USD" and isinstance(home.get("price"),(int,float)) and home["price"]>0:
                facts.append(home["price"])
            status[sts]+=1;dates[day]+=1;zips[str(home.get("zipcode") or "Missing")]+=1
            rows_first=rows_first or index;rows_last=index
            if t:time_min=min(time_min or t,t);time_max=max(time_max or t,t)
        for k in sorted(input_fields):
            counts=[f"{why} ({n:,})" for (field,why),n in sorted(change.items()) if field==k]
            detail=REDACTION.get(k,"Retained" if not counts else "Retained where applicable")
            if counts:detail += ". Adjustments: "+", ".join(counts)
            fields.writerow([k,input_fields[k],source_nonempty[k],delivered_present[k],delivered_nonempty[k],detail])
        for k in sorted(path_counts): nested.writerow([k,", ".join(sorted(path_types[k])),path_counts[k]])
    if not baseline.keys()<=seen_ids:raise ValueError("A previously included Zillow ID was lost.")
    summary={
        "source_url":SOURCE,"source_revision":SOURCE_REV,"source_sha256":SOURCE_SHA256,
        "source_rows":sum(raw_counts.values()),"source_property_types":dict(raw_types.most_common()),"source_statuses":dict(raw_status),
        "source_capture_dates_utc":dict(raw_dates),"source_dispositions":dict(raw_counts),
        "homes":len(seen_ids),"previous_1000":edits["previous_1000"],"new_since_previous":len(seen_ids)-edits["previous_1000"],
        "source_first_included_position":rows_first,"source_last_included_position":rows_last,
        "included_statuses":dict(status),"included_capture_dates_utc":dict(dates),"capture_first_utc":time_min,"capture_last_utc":time_max,
        "address_review":dict(flags),"zip_counts":dict(zips.most_common()),"distinct_zip_codes":len(zips.keys()-{"Missing"}),
        "nonempty_delivered_fields":dict(sorted(delivered_nonempty.items())),"source_field_count":len(input_fields),
        "retained_source_field_count":len(delivered_fields),"delivered_path_count":len(path_types),
        "confirmed_living_area_sqft":edits["confirmed_living_area_sqft"],"history_and_schools_counts":dict(hist),
        "positive_usd_asks":len(facts),"asking_min_usd":min(facts),"asking_max_usd":max(facts),"asking_median_usd":median(facts),
        "asking_quartiles_usd":quantiles(facts,method="inclusive")
    }
    (dest/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    return summary


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source",type=Path);parser.add_argument("out",type=Path)
    parser.add_argument("--prior",type=Path,default=Path(__file__).resolve().parents[1]/"prior_1000_index.csv")
    args=parser.parse_args()
    result=build(args.source,args.out,args.prior)
    print(json.dumps({k:v for k,v in result.items() if k not in {"zip_counts","nonempty_delivered_fields"}},indent=2))
