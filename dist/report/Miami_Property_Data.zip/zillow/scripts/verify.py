"""Verify the exported sample against the exact source, including the exclusion ledger and protected fields."""
import argparse
import csv
import gzip
import hashlib
import json
from collections import Counter
from itertools import zip_longest
from pathlib import Path
from statistics import median
from build import CONTACT, DROP_KEYS, HIDDEN_KEYS, URL_OR_SECRET, clean_home, in_scope, safe_link, undisclosed
from source_facts import CORE, SOURCE_SHA256, present, confirmed_sqft
from source_records import iter_records


def read_csv(path):
    with path.open(encoding="utf-8",newline="") as stream: yield from csv.DictReader(stream)


def audit_safe(value, path=()):
    if isinstance(value,dict):
        for key,v in value.items():
            assert key not in DROP_KEYS and (path or key != "description"), (path,key)
            assert not (path==("listing_provided_by",) and key=="name")
            audit_safe(v,path+(key,))
    if isinstance(value,list):
        for item in value: audit_safe(item,path)
    if isinstance(value,str):
        if CONTACT.search(value):raise AssertionError(("Contact",path))
        if URL_OR_SECRET.search(value):assert safe_link(value,path),(path,"Unexpected URL or parameter")


def verify(source,dest):
    summary=json.loads((dest/"summary.json").read_text())
    with source.open("rb") as fp:assert hashlib.file_digest(fp,"sha256").hexdigest()==summary["source_sha256"]==SOURCE_SHA256
    retained=Counter(); statuses=Counter();counts=Counter(); scope_count=0; price_values=[]
    homes=iter(read_csv(dest/"homes.csv")); audit=read_csv(dest/"source_rows.csv")
    ids=set(); addresses=set(); old=set();expected_old=set(r["zpid"] for r in read_csv(dest/"prior_1000_index.csv"))
    hidden_ids={str(r.get("zpid")) for r in iter_records(source) if in_scope(r) and undisclosed(r)}
    with gzip.open(dest/"miami_homes.jsonl.gz","rt",encoding="utf-8") as detail:
        for index,(raw,ledger) in enumerate(zip_longest(iter_records(source),audit),1):
            assert raw is not None and ledger is not None
            assert int(ledger["source_array_position_1_based"])==index
            counts[ledger["disposition"]]+=1
            included=in_scope(raw)
            assert (ledger["disposition"]=="Included")==included
            if not included:continue
            scope_count+=1;row=next(homes);h=json.loads(next(detail));zid=str(raw["zpid"])
            assert row["zpid"]==zid==str(h["zpid"])==ledger["included_zpid"] and zid not in ids
            ids.add(zid);statuses[h["homeStatus"]]+=1
            if row["previous_1000"]=="1":old.add(zid)
            assert row["previous_1000"]==ledger["previous_1000"]
            assert row["source_array_position_1_based"]==str(index)
            assert row["property_profile"]
            if row["address_review"]=="Undisclosed address":
                assert not (set(h)-HIDDEN_KEYS-{"url"})
                if h.get("url"):
                    assert h["url"]==f"https://www.zillow.com/homedetails/Miami-FL-{h['zipcode']}/{zid}_zpid/"
            else:
                street=(" ".join(h["streetAddress"].casefold().split()),h["zipcode"])
                assert street not in addresses
                addresses.add(street)
            for col,key in CORE:
                assert row[col]==("" if h.get(key) is None else str(h.get(key))), (index,key)
            assert h==clean_home(raw,hidden_ids,Counter()), index
            audit_safe(h)
            sqft=confirmed_sqft(h)
            assert row["confirmed_living_area_sqft"]==("" if sqft is None else str(sqft))
            retained.update(k for k,v in h.items() if present(v))
            if h.get("homeStatus")=="FOR_SALE" and h.get("currency")=="USD" and (h.get("price") or 0)>0:
                price_values.append(h["price"])
        assert next(detail,None) is None and next(homes,None) is None
    assert len(ids)==scope_count==summary["homes"] and old==expected_old
    assert counts==summary["source_dispositions"] and sum(counts.values())==summary["source_rows"]
    assert statuses==summary["included_statuses"] and median(price_values)==summary["asking_median_usd"]
    assert len(price_values)==summary["positive_usd_asks"]
    for f in read_csv(dest/"source_fields.csv"):
        assert int(f["delivered_nonempty"])==retained[f["source_field"]]
    print(f"Verified all {sum(counts.values()):,} source dispositions, {len(ids):,} home rows, {len(old):,} previous IDs and detail-field redactions.")


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("source",type=Path);ap.add_argument("out",type=Path)
    a=ap.parse_args();verify(a.source,a.out)
