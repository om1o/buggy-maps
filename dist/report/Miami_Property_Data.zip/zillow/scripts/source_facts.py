from collections import defaultdict
import re

SOURCE_SHA256 = "458364a7d56c3c49a4e2ce6d1518a0028383b49c393aa98a3c7cf39e92d000a7"
SOURCE_REV = "05c08ac6a6afabaf074cd0061164600caa85e969"
SOURCE = "https://huggingface.co/datasets/dev0524/resi-dataset/resolve/" + SOURCE_REV + "/miami-fl.json"
INTERIOR_SQFT = re.compile(r"^Total interior livable area:\s*([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s?ft\.?|square feet)\s*$", re.I)

def present(v):
    return v is not None and v != "" and v != [] and v != {}



CORE = [
    ("zpid", "zpid"), ("street_address", "streetAddress"), ("city", "city"), ("state", "state"),
    ("zip_code", "zipcode"), ("asking_price_usd", "price"), ("status_at_capture", "homeStatus"),
    ("home_type", "homeType"), ("bedrooms", "bedrooms"), ("bathrooms", "bathrooms"),
    ("living_area", "livingArea"), ("living_area_source_unit", "livingAreaUnits"),
    ("lot_area", "lotAreaValue"), ("lot_area_unit", "lotAreaUnits"),
    ("year_built", "yearBuilt"), ("zestimate_usd", "zestimate"), ("rent_zestimate_usd_per_month", "rentZestimate"),
    ("last_sale_price_usd", "lastSoldPrice"), ("last_sale_date", "dateSoldString"),
    ("assessed_value_usd", "taxAssessedValue"), ("assessment_year", "taxAssessedYear"),
    ("days_on_zillow", "daysOnZillow"), ("latitude", "latitude"), ("longitude", "longitude"),
    ("county_fips", "countyFIPS"), ("parcel_id", "parcelId"), ("mls_id", "mls_id"),
    ("captured_utc", "timestamp"), ("zillow_url", "url"),
]



def confirmed_sqft(h):
    area = h.get("livingArea")
    if area is None:
        return None
    if str(h.get("livingAreaUnits") or h.get("livingAreaUnitsShort")).lower() in {"sqft", "square feet"}:
        return area
    for group in h.get("interior_full") or []:
        for item in group.get("values") or []:
            match = INTERIOR_SQFT.fullmatch(item)
            if match and float(match[1].replace(",", "")) == area:
                return area
    return None


def paths(value, route, acc):
    if isinstance(value, dict):
        for k, v in value.items():
            p = f"{route}.{k}" if route else k
            acc[p].add(type(v).__name__)
            paths(v, p, acc)
    elif isinstance(value, list):
        for v in value:
            paths(v, route + "[]", acc)


