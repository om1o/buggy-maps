"""Build the four additional observations from the two original, hash-verified source files."""
import argparse
import csv
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path
from urllib.parse import quote
from build import CORE, SOURCE_REV, clean_home, confirmed_sqft, in_scope, profile, undisclosed, unit_marker
from source_records import iter_records
from verify import audit_safe,read_csv


def build_later(originals,base):
    dest=base/"later";dest.mkdir(exist_ok=True)
    coverage=json.loads((dest/"source_coverage.json").read_text())
    assert coverage["archive_revision"]==SOURCE_REV
    sources=[v for v in coverage["files"] if v["miami_single_family"]]
    hidden_ids={r["zpid"] for r in read_csv(base/"homes.csv") if r["address_review"]=="Undisclosed address"}
    base_ids={r["zpid"] for r in read_csv(base/"homes.csv")}
    seen=set();summaries=[];raw_home_records=[]
    for meta in sources:
        file=meta["file"];source=originals/file
        with source.open("rb") as fp:assert hashlib.file_digest(fp,"sha256").hexdigest()==meta["sha256"]
        url="https://huggingface.co/datasets/dev0524/resi-dataset/resolve/"+SOURCE_REV+"/"+quote(file)
        matched=0
        for i,raw in enumerate(iter_records(source),1):
            if in_scope(raw):
                if undisclosed(raw):hidden_ids.add(str(raw.get("zpid")))
                raw_home_records.append((raw,file,url,meta["sha256"],i));matched+=1
        assert i==meta["records"] and matched==meta["miami_single_family"]
    with (dest/"observations.csv").open("w",encoding="utf-8",newline="") as fc,(dest/"observations.jsonl.gz").open("wb") as fp,gzip.GzipFile(filename="",mode="wb",mtime=0,compresslevel=6,fileobj=fp) as gz:
        writer=csv.writer(fc);writer.writerow([k for k,_ in CORE]+["confirmed_living_area_sqft","property_profile","address_review","previous_1000","source_array_position_1_based","source_file","source_url","source_file_sha256","source_price_amount","source_currency"])
        for raw,file,url,digest,seq in raw_home_records:
            h=clean_home(raw,hidden_ids,Counter());audit_safe(h)
            zid=str(h["zpid"]); captured=h["timestamp"]
            assert zid not in base_ids and zid not in seen
            seen.add(zid)
            provenance={"source_file":file,"source_url":url,"source_file_sha256":digest,"source_array_position_1_based":seq}
            flags="Undisclosed address" if undisclosed(raw) else "Unit marker in source" if unit_marker(raw) else "No address exception"
            sqft=confirmed_sqft(h); flat=[h.get(k) if col!="asking_price_usd" or (h.get("homeStatus")=="FOR_SALE" and h.get("currency")=="USD") else None for col,k in CORE]
            writer.writerow(flat+[sqft,profile(h,sqft,flags),flags,0,seq,file,url,digest,h.get("price"),h.get("currency")])
            wrapped={"provenance":provenance,"home":h}
            gz.write((json.dumps(wrapped,ensure_ascii=False,allow_nan=False,separators=(",",":"))+"\n").encode())
            summaries.append(dict(zpid=zid,snapshot_at=captured,source_status=h["homeStatus"],last_sale_date=h.get("dateSoldString"),last_sale_price=h.get("lastSoldPrice"),**provenance))
    # Read both final files independently and reconcile prices and global uniqueness.
    csvrows=list(read_csv(dest/"observations.csv"))
    with gzip.open(dest/"observations.jsonl.gz","rt",encoding="utf-8") as f:details=[json.loads(v) for v in f]
    assert len(csvrows)==len(details)==len(seen)==len(raw_home_records)
    assert {str(r["home"]["zpid"]) for r in details}=={r["zpid"] for r in csvrows}==seen
    for row,entry in zip(csvrows,details):
        h=entry["home"];audit_safe(h)
        assert row["asking_price_usd"]=="" and row["source_price_amount"]==str(h["price"])==str(h["lastSoldPrice"])
        assert row["source_file_sha256"]==entry["provenance"]["source_file_sha256"]
    (dest/"verified.json").write_text(json.dumps({"additional_observations":len(seen),"unique_ids_including_base":len(seen|base_ids),"coverage":dict(Counter(v["snapshot_at"][:10] for v in summaries)),"observations":summaries},indent=2)+"\n")
    print(f"Verified {len(seen)} extra distinct identifiers from {len(sources)} complete source files. Total {len(seen|base_ids):,}.")

if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("original_files_dir",type=Path);ap.add_argument("base",type=Path)
    a=ap.parse_args();build_later(a.original_files_dir,a.base)
