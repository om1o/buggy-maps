"""Stream the top-level objects from the published Miami JSON array."""
import json
import re


UNIT_STREET = re.compile(r"\b(?:apt|apartment|unit|ste|suite)\b|#", re.I)


def iter_records(source):
    decoder = json.JSONDecoder()
    buffer = ""
    eof = False
    with open(source, encoding="utf-8-sig") as stream:
        while True:
            buffer = buffer.lstrip(" \t\r\n[,")
            if buffer.startswith("]") or (eof and not buffer):
                return
            try:
                record, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                if eof:
                    raise
                block = stream.read(1024 * 1024)
                eof = not block
                buffer += block
                continue
            yield record
            buffer = buffer[end:]
