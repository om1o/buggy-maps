# Three November asking-price checks

On November 15, 2026, three Miami-mailing-area single-family homes were checked individually against public Zillow and Homes.com property pages. Each pair displayed the same street address, ZIP, MLS ID and asking price. The Zillow pages showed “For sale” and the Homes.com listings gave an MLS status of “Active.”

| House | ZIP | MLS ID | Zillow asking | Homes.com asking |
| --- | --- | --- | ---: | ---: |
| 1829 NW 62nd Ter | 33147 | A12071702 | $425,000 | $425,000 |
| 1861 SW 22nd Ter | 33145 | A12088401 | $1,150,000 | $1,150,000 |
| 5550 SW 87th Ave | 33165 | A12098257 | $1,500,000 | $1,500,000 |

The CSV supplies both property-page URLs, the last listing event date on each site and each page's displayed search-index age at review. The dates record listing events and can differ across portals. For example, the 1861 SW 22nd Ter listing history starts on September 13 on Homes.com and September 14 on Zillow.

Page ages were reported relative to November 15. The Zillow copies were labeled “last week,” “6 days ago” and “5 days ago.” The corresponding Homes.com copies were labeled “today,” “today” and “3 days ago.” The status labels reflect those indexed pages. The search index did not provide a synchronized November 15 MLS reading.

One address, 5550 SW 87th Ave, also appears in the file of eight historical property examples. The two files cover ten distinct Homes.com property pages. Selection was purposive, so three matching prices do not establish a market-wide agreement rate.
