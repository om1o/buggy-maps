# Homes.com property research

Reviewed November 15, 2026. The file `homescom_examples.csv` documents eight individually researched single-family properties. Seven street addresses and ZIP codes match properties in the March 6 Zillow archive. Six of the seven also have matching MLS IDs. The later listing for 5550 SW 87th Ave has a different MLS ID at the same address.

## Search geography and availability

The Homes.com Miami single-family search displayed 3,895 results when reviewed. Search cards on that page included addresses in Hialeah, Coral Gables and Doral. A Miami mailing address can also extend beyond the incorporated city. The eighth research example, 6531 SW 20th St, has Miami in the page heading and West Miami in the listing details. The search count cannot establish the number of properties inside city limits or the percentage covered by either source. [Homes.com Miami single-family search](https://www.homes.com/miami-fl/houses-for-sale/)

Public searches across dataset catalogs and host repositories did not identify a verified, authorized Miami-wide export originating from Homes.com. Homes.com restricts bulk collection and database uses without permission. A complete inventory comparison would require appropriately authorized, same-date records from each portal and a shared geographic boundary. [Homes.com Terms of Use, sections 3 and 4](https://www.homes.com/about/homesterms-of-use/)

## Reading the columns

- `homescom_url` links to the source for each researched property. `review_date` records when the published information was checked. Search-index copies of individual pages had different capture dates.
- `history_event`, `history_event_date` and `event_price_usd` record one dated entry in the property's sale or listing history. The four sale prices describe completed transactions. The two for-sale events and two price changes describe asking prices at those dates. All eight rows are historical observations.
- `beds`, `baths`, `living_sqft`, `lot_sqft`, `year_built` and `homescom_mls_id` come from the Homes.com pages. Baths may include a half bath. Lot area uses the square-foot figure reported separately from rounded acres. The sources differ on the lot size at 831 NW 21st Ct. The row includes both figures in its note.
- `annual_tax_usd` and `tax_year` come from the property's tax or listing section. Amounts apply to the year given.
- Fields beginning with `zillow_march_` describe the matched March 6 archive record. Blanks mean there was no verified March match. The four sold examples were chosen to illustrate dated changes. They do not estimate the share of all listings that sold.
- Each record includes the home address and its source's city, state and ZIP label. No municipal boundary check was applied.
