# Zillow property records for 1,000 Miami houses

[Open the five-slide presentation](https://chatgpt.com/space/page_fe47a9446ab08191a5089a2f44e4ac19).

## Asking prices

The sample covers 39 Miami ZIP codes. Its median asking price was $855,000 on March 6, 2026. The 25th and 75th percentiles were $659,750 and $1,600,000. Recorded asking prices ranged from $249,999 to $110 million.

## Field coverage

| Field | Homes with a value | Missing |
| --- | ---: | ---: |
| Asking price | 1,000 | 0 |
| Bedrooms | 1,000 | 0 |
| Bathrooms | 1,000 | 0 |
| Year built | 1,000 | 0 |
| Living area | 986 | 14 |
| Last sold price | 833 | 167 |
| Rent Zestimate | 471 | 529 |
| Zestimate | 413 | 587 |

## Two listings that later sold

The archive shows an asking price of $600,000 for 15264 SW 102nd Ct, Miami, FL 33157. Zillow records a price cut to $575,000 on March 16 and a sale for $560,000 on April 28, 2026. Both records show 4 bedrooms, 2 bathrooms and 1,631 square feet. [Zillow property page](https://www.zillow.com/homedetails/15264-SW-102nd-Ct-Miami-FL-33157/44298025_zpid/).

The March 6 asking price for 6735 SW 51st St was $1,175,000. Zillow records a sale for $1,115,000 on July 8, 2026. [Zillow property page](https://www.zillow.com/homedetails/6735-SW-51st-St-Miami-FL-33155/44206273_zpid/).

## Source and selection

The first 1,000 eligible records in source order each had a single-family home marked for sale, a disclosed Miami address, a Zillow URL and a positive USD asking price. The selection screened out explicitly unit-marked addresses. Both the Zillow property ID and the street-address/ZIP pair are unique in the sample. Two Zillow pages were spot-checked on November 14, 2026. The results describe the archived sample, and current availability remains unverified for the full set. [Pinned source revision](https://huggingface.co/datasets/dev0524/resi-dataset/tree/05c08ac6a6afabaf074cd0061164600caa85e969).
