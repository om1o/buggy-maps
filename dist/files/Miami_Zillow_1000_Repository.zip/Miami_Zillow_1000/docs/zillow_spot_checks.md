# Two Zillow listing checks

The archive dates to March 6, 2026 UTC. Zillow's property histories confirm the asking prices shown for these two homes at that time and record sales later in 2026. The March workbook preserves the original asking prices and statuses.

| Address | Beds / baths | Living area | March 6 asking price | Later event on Zillow |
| --- | --- | ---: | ---: | --- |
| 15264 SW 102nd Ct, Miami, FL 33157 | 4 / 2 | 1,631 sq ft | $600,000 | Price cut to $575,000 on March 16. Sold for $560,000 on April 28, 2026. |
| 6735 SW 51st St, Miami, FL 33155 | 3 / 2 | 2,192 sq ft | $1,175,000 | Pending on June 11. Sold for $1,115,000 on July 8, 2026. |

[Zillow history for 15264 SW 102nd Ct](https://www.zillow.com/homedetails/15264-SW-102nd-Ct-Miami-FL-33157/44298025_zpid/)  
[Zillow history for 6735 SW 51st St](https://www.zillow.com/homedetails/6735-SW-51st-St-Miami-FL-33155/44206273_zpid/)

Checked November 14, 2026. Current availability or later sale prices were checked only for these two sample properties.
