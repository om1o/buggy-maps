"""Verify the delivered tables against the detailed property archive."""
import argparse
import csv
import gzip
import json
from collections import Counter
from pathlib import Path
from statistics import median, quantiles

from records import UNIT_STREET


def read_csv(path):
    with path.open(encoding="utf-8", newline="") as stream:
        yield from csv.DictReader(stream)


def verify(dest):
    summary = json.loads((dest / "summary.json").read_text())
    with gzip.open(dest / "miami_homes.jsonl.gz", mode="rt", encoding="utf-8") as stream:
        homes = [json.loads(line) for line in stream]
    ids = [str(h["zpid"]) for h in homes]
    street_keys = {(" ".join(h["streetAddress"].lower().split()), h["zipcode"]) for h in homes}
    assert len(ids) == len(set(ids)) == len(street_keys) == len({h["url"] for h in homes}) == 1000
    assert all(h["city"] == "Miami" and h["state"] == "FL" and h["homeType"] == "SINGLE_FAMILY" and
               h["homeStatus"] == "FOR_SALE" and h["currency"] == "USD" and h["price"] > 0 and
               h["timestamp"].startswith("2026-03-06T") and not UNIT_STREET.search(h["streetAddress"]) and
               f"/{h['zpid']}_zpid/" in h["url"] for h in homes)
    amounts = [h["price"] for h in homes]
    assert (min(amounts), median(amounts), max(amounts)) == (
        summary["min_asking_usd"], summary["median_asking_usd"], summary["max_asking_usd"])
    assert quantiles(amounts, method="inclusive") == summary["asking_quartiles_usd"]
    assert Counter(h["zipcode"] for h in homes) == summary["zip_counts"]
    flat = list(read_csv(dest / "homes.csv"))
    assert [r["zpid"] for r in flat] == ids
    for row, home in zip(flat, homes):
        assert row["street_address"] == home["streetAddress"] and int(row["asking_price_usd"]) == home["price"]
        assert row["zillow_url"] == home["url"] and row["property_profile"]
    row_map = list(read_csv(dest / "source_rows.csv"))
    assert [r["zpid"] for r in row_map] == ids
    positions = [int(r["source_array_position_1_based"]) for r in row_map]
    assert positions == sorted(set(positions))
    fields = list(read_csv(dest / "source_fields.csv"))
    keys = {k for h in homes for k in h}
    assert len(fields) == summary["source_fields"] and len(keys) == summary["retained_top_level_fields"]
    for field in fields:
        n = sum(h.get(field["source_key"]) not in (None, "", [], {}) for h in homes)
        assert n == int(field["delivered_nonempty"]), field["source_key"]
    for table, key in (("price_history", "priceHistory"), ("tax_history", "taxHistory"), ("schools", "schools")):
        expected = Counter({str(h["zpid"]): len(h.get(key) or []) for h in homes})
        observed = Counter(row["zpid"] for row in read_csv(dest / (table + ".csv")))
        assert expected == observed, table
    features = Counter()
    for h in homes:
        for category in ("interior_full", "property", "construction", "community_details"):
            features[str(h["zpid"])] += sum(len(item.get("values") or []) for item in h.get(category) or [])
    assert features == Counter(row["zpid"] for row in read_csv(dest / "home_features.csv"))
    for h in homes:
        assert not {"photos", "postingContact", "description", "streetViewTileImageUrlMediumLatLong"}.intersection(h)
        assert not {"name", "email", "phone_number"}.intersection(h.get("listing_provided_by") or {})
    print(f"Verified {len(homes):,} distinct homes, {len(keys)} retained fields, {len(summary['zip_counts'])} ZIPs.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_dir", type=Path)
    verify(parser.parse_args().data_dir)
