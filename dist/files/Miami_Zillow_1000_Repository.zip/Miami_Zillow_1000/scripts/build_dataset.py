"""Build the Miami archive from its pinned public source with the Python standard library."""
import argparse
import csv
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median, quantiles

from records import choose


SOURCE_SHA256 = "458364a7d56c3c49a4e2ce6d1518a0028383b49c393aa98a3c7cf39e92d000a7"
SOURCE_REV = "05c08ac6a6afabaf074cd0061164600caa85e969"
SOURCE = "https://huggingface.co/datasets/dev0524/resi-dataset/resolve/" + SOURCE_REV + "/miami-fl.json"
MEDIA_KEYS = {"photos", "photo", "miniCardPhotos", "compsCarouselPropertyPhotos", "providerLogo",
              "streetViewTileImageUrlMediumLatLong", "jpeg"}
CONTACT_KEYS = {"agentName", "agentPhoneNumber", "brokerPhoneNumber", "postingContact",
                "email", "phone_number"}
MEDIA_URL = re.compile(r"photos\.zillowstatic\.com|streetview\?|\.(?:jpe?g|png|gif|webp)(?:$|[?#])|[?&](?:key|signature|token)=", re.I)
SKIP = object()
INTERIOR_SQFT = re.compile(r"^Total interior livable area:\s*([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s?ft\.?|square feet)\s*$", re.I)
EXCLUDED = {"photos": "Image array omitted", "streetViewTileImageUrlMediumLatLong": "Image URL omitted",
            "description": "Original marketing text omitted. See the listing URL and factual profile in homes.csv.",
            "postingContact": "Contact details omitted"}
TREATMENT = {
    "listing_provided_by": "Company retained when present. Personal name, email and phone omitted.",
    "homeValuation": "Structured comparable-property records retained. Media and personal contact fields omitted.",
    "nearbyHomes": "Structured nearby-home records retained. Embedded media and personal contact fields omitted.",
    "priceHistory": "Event records retained. Image URLs in source attribution omitted.",
}


def present(v):
    return v is not None and v != "" and v != [] and v != {}


def clean(v, path=()):
    if isinstance(v, str):
        if v.lstrip().startswith(("{", "[")):
            try:
                return clean(json.loads(v), path)
            except ValueError:
                pass
        return SKIP if MEDIA_URL.search(v) else v
    if isinstance(v, list):
        return [x for item in v if (x := clean(item, path)) is not SKIP]
    if isinstance(v, dict):
        result = {}
        for key, value in v.items():
            if (key in MEDIA_KEYS or key in CONTACT_KEYS or (not path and key == "description")
                    or (path == ("listing_provided_by",) and key == "name")):
                continue
            filtered = clean(value, (*path, key))
            if filtered is not SKIP:
                result[key] = filtered
        return result
    return v


CORE = [
    ("zpid", "zpid"), ("street_address", "streetAddress"), ("city", "city"), ("state", "state"),
    ("zip_code", "zipcode"), ("asking_price_usd", "price"), ("status_at_capture", "homeStatus"),
    ("home_type", "homeType"), ("bedrooms", "bedrooms"), ("bathrooms", "bathrooms"),
    ("living_area", "livingArea"), ("living_area_source_unit", "livingAreaUnits"),
    ("lot_area", "lotAreaValue"), ("lot_area_unit", "lotAreaUnits"),
    ("year_built", "yearBuilt"), ("zestimate_usd", "zestimate"), ("rent_zestimate_usd_per_month", "rentZestimate"),
    ("last_sale_price_usd", "lastSoldPrice"), ("last_sale_date", "dateSoldString"),
    ("assessed_value_usd", "taxAssessedValue"), ("assessment_year", "taxAssessedYear"),
    ("days_on_zillow", "daysOnZillow"), ("latitude", "latitude"), ("longitude", "longitude"),
    ("county_fips", "countyFIPS"), ("parcel_id", "parcelId"), ("mls_id", "mls_id"),
    ("captured_utc", "timestamp"), ("zillow_url", "url"),
]


def profile(h):
    parts = [f"{h['bedrooms']}-bedroom, {h['bathrooms']}-bathroom single-family house in ZIP {h['zipcode']}",
             f"built in {h['yearBuilt']}"]
    if h.get("lotAreaValue") and h.get("lotAreaUnits"):
        u = str(h["lotAreaUnits"]).lower().replace("sqft", "square feet")
        parts.append(f"lot of {h['lotAreaValue']:,} {u}")
    return ". ".join(x[0].upper() + x[1:] for x in parts) + "."


def confirmed_sqft(h):
    area = h.get("livingArea")
    if area is None:
        return None
    if str(h.get("livingAreaUnits") or h.get("livingAreaUnitsShort")).lower() in {"sqft", "square feet"}:
        return area
    for group in h.get("interior_full") or []:
        for item in group.get("values") or []:
            match = INTERIOR_SQFT.fullmatch(item)
            if match and float(match[1].replace(",", "")) == area:
                return area
    return None


def paths(value, route, acc):
    if isinstance(value, dict):
        for k, v in value.items():
            p = f"{route}.{k}" if route else k
            acc[p].add(type(v).__name__)
            paths(v, p, acc)
    elif isinstance(value, list):
        for v in value:
            paths(v, route + "[]", acc)


def generate(source_path, dest):
    with source_path.open("rb") as f:
        if hashlib.file_digest(f, "sha256").hexdigest() != SOURCE_SHA256:
            raise ValueError("Source SHA-256 does not match the published Miami file.")
    dest.mkdir(parents=True, exist_ok=True)
    appearances, raw_nonempty, delivered_nonempty = Counter(), Counter(), Counter()
    path_types, path_counts = defaultdict(set), Counter()
    facts, zip_counts, when = [], Counter(), Counter()
    history = Counter()
    with (dest / "homes.csv").open("w", newline="", encoding="utf-8") as cf, (dest / "source_rows.csv").open("w", newline="", encoding="utf-8") as sf, gzip.open(dest / "miami_homes.jsonl.gz", "wt", encoding="utf-8", compresslevel=6) as jf:
        table = csv.writer(cf)
        table.writerow([label for label, _ in CORE] + ["confirmed_living_area_sqft", "property_profile"])
        index = csv.writer(sf)
        index.writerow(["zpid", "source_array_position_1_based"])
        for seq, raw in choose(source_path):
            for field, v in raw.items():
                appearances[field] += 1
                if present(v):
                    raw_nonempty[field] += 1
            h = clean(raw)
            for field, v in h.items():
                if present(v):
                    delivered_nonempty[field] += 1
            index.writerow([h["zpid"], seq])
            table.writerow([h.get(key) for _, key in CORE] + [confirmed_sqft(h), profile(h)])
            jf.write(json.dumps(h, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            obs = defaultdict(set)
            paths(h, "", obs)
            for p, types in obs.items():
                path_types[p].update(types)
                path_counts[p] += 1
            facts.append(h["price"])
            zip_counts[h["zipcode"]] += 1
            when[h["timestamp"][:10]] += 1
            for key in ("priceHistory", "taxHistory", "zestimate_history"):
                history[key] += len(h.get(key) or [])
    if len(facts) != 1000:
        raise ValueError(f"Expected 1,000 distinct homes. Found {len(facts)}.")
    with (dest / "source_fields.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["source_key", "source_nonempty", "delivered_nonempty", "treatment", "source_present"])
        for k in sorted(appearances):
            w.writerow([k, raw_nonempty[k], delivered_nonempty[k], EXCLUDED.get(k, TREATMENT.get(k, "Retained")), appearances[k]])
    with (dest / "field_paths.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["json_path", "observed_types", "homes_with_path_including_null"])
        for k in sorted(path_types):
            w.writerow([k, ", ".join(sorted(path_types[k])), path_counts[k]])
    summary = dict(homes=len(facts), distinct_zip_codes=len(zip_counts), capture_dates=when,
                   source_fields=len(appearances), retained_top_level_fields=len(appearances.keys()-EXCLUDED.keys()),
                   median_asking_usd=median(facts), min_asking_usd=min(facts), max_asking_usd=max(facts),
                   asking_quartiles_usd=quantiles(facts, method="inclusive"), history_entries=history,
                   zip_counts=dict(zip_counts.most_common()), source_url=SOURCE, source_revision=SOURCE_REV,
                   source_sha256=SOURCE_SHA256)
    (dest / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    generate(args.source, args.output_dir)
