"""Make frequently used nested records available as CSVs keyed by the parent Zillow ID."""
import argparse
import csv
import gzip
import json
from contextlib import ExitStack
from pathlib import Path


TABLES = {
    "price_history": ("priceHistory", [
        ("event_date", "date"), ("event", "event"), ("price_usd", "price"),
        ("is_rental_event", "postingIsRental"), ("price_per_sq_ft", "pricePerSquareFoot"),
        ("price_change_fraction", "priceChangeRate"), ("source", "source"),
        ("source_listing_id", "source_listing_id"), ("source_name", "source_name")]),
    "tax_history": ("taxHistory", [
        ("tax_year", "time"), ("tax_paid_usd", "taxPaid"), ("assessment_usd", "value"),
        ("assessment_change_fraction", "valueIncreaseRate")]),
    "schools": ("schools", [
        ("school", "name"), ("grades", "grades"), ("distance_source_value", "distance"),
        ("rating_source_value", "rating"), ("level", "level"), ("type", "type"), ("school_url", "link")]),
}


def write_tables(dest):
    with ExitStack() as stack:
        writers = {}
        for name, (_, fields) in TABLES.items():
            f = stack.enter_context((dest / f"{name}.csv").open("w", encoding="utf-8", newline=""))
            writers[name] = csv.writer(f)
            writers[name].writerow(["zpid", "source_entry_1_based"] + [label for label, _ in fields])
        details = csv.writer(stack.enter_context((dest / "home_features.csv").open("w", encoding="utf-8", newline="")))
        details.writerow(["zpid", "section", "topic", "fact"])
        records = stack.enter_context(gzip.open(dest / "miami_homes.jsonl.gz", "rt", encoding="utf-8"))
        for line in records:
            home = json.loads(line)
            for name, (field, columns) in TABLES.items():
                for i, item in enumerate(home.get(field) or [], start=1):
                    writers[name].writerow([home["zpid"], i] + [item.get(key) for _, key in columns])
            for key in ("interior_full", "property", "construction", "community_details"):
                for group in home.get(key) or []:
                    for fact in group.get("values") or []:
                        details.writerow([home["zpid"], key, group["title"], fact])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    write_tables(parser.parse_args().output_dir)
