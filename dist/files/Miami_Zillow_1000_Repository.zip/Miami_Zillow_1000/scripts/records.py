"""Stream the top-level objects from the published Miami JSON array."""
import json
import re


UNIT_STREET = re.compile(r"\b(?:apt|apartment|unit|ste|suite)\b|#", re.I)


def iter_records(source):
    decoder = json.JSONDecoder()
    buffer = ""
    eof = False
    with open(source, encoding="utf-8-sig") as stream:
        while True:
            buffer = buffer.lstrip(" \t\r\n[,")
            if buffer.startswith("]") or (eof and not buffer):
                return
            try:
                record, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                if eof:
                    raise
                block = stream.read(1024 * 1024)
                eof = not block
                buffer += block
                continue
            yield record
            buffer = buffer[end:]


def choose(source, size=1000):
    seen_ids, seen_addresses = set(), set()
    for index, home in enumerate(iter_records(source), start=1):
        if (home.get("city") != "Miami" or home.get("state") != "FL" or
                home.get("homeType") != "SINGLE_FAMILY" or home.get("homeStatus") != "FOR_SALE" or
                home.get("currency") != "USD" or (home.get("price") or 0) <= 0):
            continue
        zpid = str(home.get("zpid") or "")
        street = " ".join((home.get("streetAddress") or "").casefold().split())
        zip_code = str(home.get("zipcode") or "")
        address = (street, zip_code)
        if not (zpid.isdigit() and street and zip_code and
                (home.get("url") or "").startswith("https://www.zillow.com/homedetails/") and
                f"/{zpid}_zpid" in home["url"]):
            continue
        if zpid in seen_ids or address in seen_addresses:
            continue
        if ("undisclosed" in street or str(home.get("isUndisclosedAddress")).lower() == "true"
                or UNIT_STREET.search(street) or home.get("unit_number")):
            continue
        seen_ids.add(zpid)
        seen_addresses.add(address)
        yield index, home
        if len(seen_ids) == size:
            return
