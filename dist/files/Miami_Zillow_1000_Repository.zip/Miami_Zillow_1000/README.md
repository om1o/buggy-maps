# Miami houses on Zillow

One thousand Miami, Florida, houses that the source recorded as single-family and for sale on **March 6, 2026 (UTC)**. The archive covers 39 ZIP codes. Each house has a distinct Zillow property ID, a distinct street-address and ZIP combination, and its original Zillow listing URL.

| Sample measure | Result |
| --- | ---: |
| Median asking price | $855,000 |
| Middle half of asking prices | $659,750 to $1,600,000 |
| Lowest and highest asking prices | $249,999 to $110,000,000 |
| Homes with a previous sale price | 833 |
| Homes with a Zestimate | 413 |
| Homes with a Rent Zestimate | 471 |

These figures describe the selected homes. The source lists them in a particular order, and the selection uses that order. The median is therefore unsuitable as an estimate for all Miami houses. Source city means the listing's city label. A Miami mailing address can fall outside the City of Miami's municipal boundary.

## Files

| File | Contents |
| --- | --- |
| `Zillow_Homes.xlsx` | Formatted workbook with individual properties, field coverage and source documentation |
| `data/homes.csv` | 1,000 rows with IDs, addresses, asking prices, beds, baths, assessed values, coordinates, listing URLs and factual property profiles |
| `data/price_history.csv` | 11,568 listing, price-change, rental or sale events. Read the event and rental flag alongside the price |
| `data/tax_history.csv` | 20,817 property-year entries, with tax paid and assessment when supplied |
| `data/home_features.csv` | 37,045 facts about construction, interiors, lots, amenities and communities |
| `data/schools.csv` | 3,000 home-to-school entries with source ratings and school links where supplied. Proximity does not establish attendance eligibility |
| `data/miami_homes.jsonl.gz` | Detailed records in compressed JSON Lines. Includes price, tax and Zestimate history, HOA details, comparable homes, listing attributes and source context where available |
| `data/source_fields.csv` | Counts and handling for every one of the 135 original top-level field names |
| `data/field_paths.csv` | The 323 field paths observed in the delivered JSON, value types and count of homes where each path exists, including explicit nulls |
| `data/source_rows.csv` | Zillow ID and original one-based record position for each house |
| `data/summary.json` | Counts by ZIP, price quartiles, capture date and source version |
| `docs/zillow_spot_checks.md` | Direct Zillow evidence for two houses, including what happened after capture |
| `docs/presentation.md` | Presentation summary and link |

Join detail tables to `homes.csv` using `zpid`. Keep ZIP, parcel, county FIPS and MLS codes as text when importing CSVs. Earlier events, school references and nearby comparables can each occupy multiple rows or array items for the same house. Nearby and comparable homes do not count toward the 1,000.

## Source and selection

The source is the publicly downloadable `miami-fl.json` file in the third-party `dev0524/resi-dataset` archive on Hugging Face. Its records link to Zillow property pages. The source file contains 6,575 records. The selected homes have timestamps from 02:23:21.405 through 02:26:06.057 UTC on March 6, 2026. These times fall on the evening of March 5 in Miami. The publisher does not document a probability sampling method.

1. Read the source in its original order. Keep records with city Miami, state FL, type `SINGLE_FAMILY`, status `FOR_SALE`, and a positive USD asking price.
2. Require a disclosed street address, ZIP code, numeric Zillow ID and original Zillow property URL containing that ID. Exclude records with a unit number or an address containing an apartment, unit or suite designation.
3. Keep the first occurrence of each Zillow ID and each street/ZIP pair. The address comparison ignores case and repeated whitespace. Stop at 1,000 eligible houses. The final house is source record 2,926.
4. Preserve the source timestamp, original price and reported status for every row. Later events found in the spot checks are documented separately.

Source revision: `05c08ac6a6afabaf074cd0061164600caa85e969`  
Source file SHA-256: `458364a7d56c3c49a4e2ce6d1518a0028383b49c393aa98a3c7cf39e92d000a7`

[Source collection](https://huggingface.co/datasets/dev0524/resi-dataset) · [Versioned Miami file](https://huggingface.co/datasets/dev0524/resi-dataset/blob/05c08ac6a6afabaf074cd0061164600caa85e969/miami-fl.json)

## Interpreting the fields

- **Asking price** is the USD amount shown at capture. A **last sale price** records an earlier transaction. A **Zestimate** is a model estimate. Rent estimates are monthly. Each measure has its own column.
- **Missing values** stay blank in CSVs. In JSON a field can be absent, explicitly null or an empty array. Zero and false are valid source values. In the field inventory, nonempty excludes null, an empty string, an empty array and an empty object.
- **Area** is preserved as reported. Some lots use acres and others use square feet. A total of 986 homes have a reported living-area value. The `confirmed_living_area_sqft` column in the CSV gives square feet for 979 homes whose dedicated unit or matching interior-detail measurement explicitly confirms the unit.
- **History** uses source dates and events. Removal, relisting or a rental event is distinct from a closed sale. Tax paid and tax-assessed value have their own columns. Source rates and changes retain their original scale. Historical Zestimate `amount` values retain source units, which the publisher does not specify.
- **Media and text**. The detailed file retains 131 original top-level fields across the sample. Photo arrays and street-view image URLs are omitted, along with image links embedded in other fields. Photo counts and tour-availability flags remain as factual metadata. Original listing descriptions are replaced in the CSV by short profiles based on structured facts. Personal contact fields are omitted. Original descriptions remain available from the linked sources.
- **Usability**. The detailed file converts embedded JSON strings in comparable and nearby-home arrays into JSON objects. Nested field paths use `[]` to identify arrays. Details retain the publisher's field names and source order.
- **Publication rights**. The archive does not identify a reuse license for the listing data. This package does not establish permission to republish listing content on a public website.

## Reproducing the data files

Use Python 3.11 or later. The scripts use only the standard library. Save the versioned source JSON as `miami-fl.json` outside this repository, then run the following commands at the repository root.

```sh
python scripts/build_dataset.py /path/to/miami-fl.json data
python scripts/export_detail_tables.py data
python scripts/verify.py data
```

The first command verifies the source file's SHA-256 before processing records. The verifier reconciles the delivered files, IDs, field counts, historical entry counts and asking-price statistics.
